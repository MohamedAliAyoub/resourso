<?php echo e($slot); ?>

<?php /**PATH D:\projects\empty projects\resourso_project\resourso\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>