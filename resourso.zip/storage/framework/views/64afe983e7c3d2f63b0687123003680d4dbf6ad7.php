<!-- regaster password -->

<script src="<?php echo e(asset('vendors/scripts/core.js')); ?>"></script>
<script src="<?php echo e(asset('src/plugins/jquery-steps/jquery.steps.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/scripts/steps-setting.js')); ?>"></script>
<!-- regaster password -->



<!-- js -->
<script src="<?php echo e(asset('vendors/scripts/core.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/scripts/script.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/scripts/process.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/scripts/layout-settings.js')); ?>"></script>
<script src="<?php echo e(asset('src/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('src/plugins/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('src/plugins/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('src/plugins/datatables/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('src/plugins/datatables/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/scripts/dashboard.js')); ?>"></script>
   </body>
</html><?php /**PATH D:\projects\empty projects\resourso_project\resourso\resources\views/layouts/footer.blade.php ENDPATH**/ ?>