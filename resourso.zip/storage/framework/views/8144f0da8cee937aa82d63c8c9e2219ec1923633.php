<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\projects\empty projects\resourso_project\resourso\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>